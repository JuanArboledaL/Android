package com.example.actividadevaluativat7.AdaptadorSpinner;

public class DatosSpinner {
    private int imagen;

    public DatosSpinner(int imagen) {

        this.imagen = imagen;
    }

    public int getImagen() {

        return imagen;
    }

    public void setImagen(int imagen) {

        this.imagen = imagen;
    }
}
